﻿using BuyMe.Models.CommonModel;
using BuyMe.Models.Model;
using BuyMe.Models.UIModel;
using BuyMe.Repository.Abstract;
using Google.Apis.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BuyMe.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : Controller
    {

        #region PRIVATE VARIABLES

        private IAccountRepository _accountRepository;
        public AccountController(IAccountRepository accountRepository)
        {
            _accountRepository = accountRepository;
        }

        #endregion

        [HttpPost("SellerRegistration")]
        public async Task<ApiResponseModel> SellerRegistration(SellerUIModel sellerUIModel)
        {
            var sellerModel = new SellerModel();

           sellerModel.sellerBasicDetailsModel.Name = sellerUIModel.sellerBasicDetailsUIModel.Name;
           sellerModel.sellerBasicDetailsModel.Email = sellerUIModel.sellerBasicDetailsUIModel.Email;
           sellerModel.sellerBasicDetailsModel.Contact = sellerUIModel.sellerBasicDetailsUIModel.Contact;
           sellerModel.sellerBasicDetailsModel.Password = sellerUIModel.sellerBasicDetailsUIModel.Password;
           sellerModel.sellerBasicDetailsModel.DateOfBirth = sellerUIModel.sellerBasicDetailsUIModel.DateOfBirth;
           sellerModel.sellerBasicDetailsModel.Gender = sellerUIModel.sellerBasicDetailsUIModel.Gender;
           sellerModel.sellerBasicDetailsModel.RoleId = sellerUIModel.sellerBasicDetailsUIModel.RoleId;
           sellerModel.sellerBasicDetailsModel.IdentificationType = sellerUIModel.sellerBasicDetailsUIModel.IdentificationType;
           sellerModel.sellerBasicDetailsModel.IdentificationNumber = sellerUIModel.sellerBasicDetailsUIModel.IdentificationNumber;
           sellerModel.sellerBasicDetailsModel.Pincode = sellerUIModel.sellerBasicDetailsUIModel.Pincode;
           sellerModel.sellerBasicDetailsModel.City = sellerUIModel.sellerBasicDetailsUIModel.City;
           sellerModel.sellerBasicDetailsModel.State = sellerUIModel.sellerBasicDetailsUIModel.State;
           sellerModel.sellerBasicDetailsModel.Country = sellerUIModel.sellerBasicDetailsUIModel.Country;
           sellerModel.sellerBasicDetailsModel.FullAddress = sellerUIModel.sellerBasicDetailsUIModel.FullAddress;
      
           sellerModel.sellerBusinessDetailsModel.BusinessName = sellerUIModel.sellerBusinessDetailsUIModel.BusinessName;
           sellerModel.sellerBusinessDetailsModel.BusinessDescription = sellerUIModel.sellerBusinessDetailsUIModel.BusinessDescription;
           sellerModel.sellerBusinessDetailsModel.BusinessEmail = sellerUIModel.sellerBusinessDetailsUIModel.BusinessEmail;
           sellerModel.sellerBusinessDetailsModel.BusinessContact = sellerUIModel.sellerBusinessDetailsUIModel.BusinessContact;
           sellerModel.sellerBusinessDetailsModel.GSTIN = sellerUIModel.sellerBusinessDetailsUIModel.GSTIN;
           sellerModel.sellerBusinessDetailsModel.Pincode = sellerUIModel.sellerBusinessDetailsUIModel.Pincode;
           sellerModel.sellerBusinessDetailsModel.City = sellerUIModel.sellerBusinessDetailsUIModel.City;
           sellerModel.sellerBusinessDetailsModel.State = sellerUIModel.sellerBusinessDetailsUIModel.State;
           sellerModel.sellerBusinessDetailsModel.Country = sellerUIModel.sellerBusinessDetailsUIModel.Country;
           sellerModel.sellerBusinessDetailsModel.FullAddress = sellerUIModel.sellerBusinessDetailsUIModel.FullAddress;
          
           sellerModel.sellerBankDetailsModel.AccountHolderName = sellerUIModel.sellerBankDetailsUIModel.AccountHolderName;
           sellerModel.sellerBankDetailsModel.AccountNumber = sellerUIModel.sellerBankDetailsUIModel.AccountNumber;
           sellerModel.sellerBankDetailsModel.IFSCCode = sellerUIModel.sellerBankDetailsUIModel.IFSCCode;
           sellerModel.sellerBankDetailsModel.BankName = sellerUIModel.sellerBankDetailsUIModel.BankName;
           sellerModel.sellerBankDetailsModel.Branch = sellerUIModel.sellerBankDetailsUIModel.Branch;

            var response = await _accountRepository.SellerRegistration(sellerModel);

            return response;
        }

        [HttpPost("UserLogin")]
        public async Task<ApiResponseModel> UserLogin(LoginModel loginModel)
        {
            var response = await _accountRepository.UserLogin(loginModel.Username, loginModel.Password);

            return response;
        }

        [HttpPost("CustomerRegistration")]
        public async Task<ApiResponseModel> CustomerRegistration(CustomerUIModel customerUIModel)
        {
            var customerModel = new CustomerModel();

            customerModel.Name = customerUIModel.Name;
            customerModel.Email = customerUIModel.Email;
            customerModel.Mobile = customerUIModel.Mobile;
            customerModel.Password = customerUIModel.Password;
            customerModel.CreatedBy = 1;

            var response = await _accountRepository.CustomerRegistration(customerModel);

            return response;

        }

        

    }
}
