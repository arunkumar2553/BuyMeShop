﻿using BuyMe.Models.CommonModel;
using BuyMe.Models.Model;
using BuyMe.Service.Interactions;
using Google.Apis.Auth;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using GoogleLoginRequest = BuyMe.Models.Model.GoogleLoginRequest;

namespace BuyMe.Web.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : Controller
    {

        private readonly IConfiguration _config;
        // Replace with your DB context or user service - here we use an in-memory store for demo:
        private static List<CustomerModel> _users = new();

        public AuthController(IConfiguration config) { _config = config; }

        [HttpPost("google")]
        public async Task<IActionResult> Google([FromBody] GoogleLoginRequest request)
        {
            if (string.IsNullOrEmpty(request.IdToken))
                return BadRequest("idToken required");

            GoogleJsonWebSignature.Payload payload;
            try
            {
                var settings = new GoogleJsonWebSignature.ValidationSettings()
                {
                    Audience = new[] { _config["Authentication:Google:ClientId"] } // must match client id of frontend
                };
                payload = await GoogleJsonWebSignature.ValidateAsync(request.IdToken, settings);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = "Invalid Google token", details = ex.Message });
            }

            // payload contains fields like Email, EmailVerified, Name, Sub (Google user id)
            if (payload == null || string.IsNullOrEmpty(payload.Email))
                return BadRequest("Invalid token payload");

            // optionally check payload.EmailVerified
            if (payload.EmailVerified != null && payload.EmailVerified != true)
                return BadRequest("Email not verified by Google");

            // Find or create user in your DB
            var user = _users.FirstOrDefault(u => u.GoogleId == payload.Subject || u.Email == payload.Email);
            if (user == null)
            {
                user = new CustomerModel
                {
                    Email = payload.Email,
                    Name = payload.Name ?? payload.Email,
                    GoogleId = payload.Subject // unique Google account id
                };
                _users.Add(user);
            }

            // Issue your app JWT
            var token = GenerateJwtToken(user);

            return Ok(new { token });
        }

        private string GenerateJwtToken(CustomerModel user)
        {
            var key = Encoding.UTF8.GetBytes(_config["Jwt:Key"]);
            var creds = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, user.Email),
            new Claim("name", user.Name)
        };

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(2),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }
}
