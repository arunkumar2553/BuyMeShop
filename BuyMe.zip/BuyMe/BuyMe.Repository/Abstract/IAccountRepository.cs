﻿using BuyMe.Models.CommonModel;
using BuyMe.Models.Model;
using Google.Apis.Auth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuyMe.Repository.Abstract
{
   public interface IAccountRepository
    {


       

        Task<ApiResponseModel> UserLogin(string username, string password);
        Task<ApiResponseModel> SellerRegistration(SellerModel sellerModel);
        Task<ApiResponseModel> CustomerRegistration(CustomerModel customerModel);
     
    }
}
