﻿using BuyMe.Models.CommonModel;
using BuyMe.Models.Model;
using BuyMe.Models.UIModel;
using BuyMe.Repository.Abstract;
using BuyMe.Service.Interactions;
using Google.Apis.Auth;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuyMe.Repository.Concrete
{
    public class AccountRepository: IAccountRepository
    {
        public async Task<ApiResponseModel> SellerRegistration(SellerModel sellerModel)
        {
            using (AccountService accountService = new AccountService())
            {
                return await accountService.SellerRegistration(sellerModel);
            }
        }

        public async Task<ApiResponseModel> UserLogin(string username, string password)
        {
            using (AccountService accountService = new AccountService())
            {
                return await accountService.UserLogin(username, password);
            }
        }

        public async Task<ApiResponseModel> CustomerRegistration(CustomerModel customerModel)
        {
            using (AccountService accountService = new AccountService())
            {
                return await accountService.CustomerRegistration(customerModel);

            }
        }

        
       
    }
}
