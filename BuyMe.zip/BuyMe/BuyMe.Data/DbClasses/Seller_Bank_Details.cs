﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuyMe.Data.DbClasses
{
   public class Seller_Bank_Details
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("Seller")]
        public int SellerId { get; set; }
        public virtual Seller Seller { get; set; }

        [StringLength(30)]
        public string Account_Holder_Name { get; set; }

        [StringLength(30)]
        public string Account_Number { get; set; }

        [StringLength(20)]
        public string IFSC_Code { get; set; }

        [StringLength(50)]
        public string Bank_Name { get; set; }

        [StringLength(50)]
        public string Branch_Address { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public bool IsActive { get; set; }
    }
}
