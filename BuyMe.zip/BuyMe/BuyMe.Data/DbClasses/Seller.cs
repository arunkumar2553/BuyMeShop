﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuyMe.Data.DbClasses
{
    public class Seller
    {
        [Key]
        public int Id { get; set; }

        [StringLength(40)]
        public string Name { get; set; }

        [StringLength(15)]
        public string Date_of_Birth { get; set; }

        [StringLength(20)]
        public string Gender { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

        [StringLength(10)]
        public string Password { get; set; }

        [StringLength(12)]
        public string Contact_No { get; set; }

        [ForeignKey("Role")]
        public int RoleId { get; set; }
        public virtual Role Role { get; set; }

        [StringLength(6)]
        public int Pincode { get; set; }

        [StringLength(30)]
        public string City { get; set; }

        [StringLength(30)]
        public string State { get; set; }

        [StringLength(30)]
        public string Country { get; set; }

        [StringLength(100)]
        public string Full_Address { get; set; }

        [StringLength(30)]
        public string Identification_Type { get; set; }

        [StringLength(30)]
        public string Identification_Number { get; set; }
       
        public DateTime? LastLoginDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public bool IsActive { get; set; }
    }
}
