﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuyMe.Data.DbClasses
{
   public class Seller_Business_Details
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("User")]
        public int SellerId { get; set; }
        public virtual Seller Seller { get; set; }

        [StringLength(30)]
        public string Business_Name { get; set; }

        [StringLength(100)]
        public string Business_Description { get; set; }

        [StringLength(12)]
        public string Contact_No { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

        [StringLength(15)]
        public string GSTIN { get; set; }

        [StringLength(6)]
        public int Pincode { get; set; }

        [StringLength(30)]
        public string City { get; set; }

        [StringLength(30)]
        public string State { get; set; }

        [StringLength(30)]
        public string Country { get; set; }

        [StringLength(100)]
        public string FullAddress { get; set; }
        public bool IsLicensed { get; set; }
        public DateTime? IsLicenseExpiredOn { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public bool IsActive { get; set; }

    }
}
