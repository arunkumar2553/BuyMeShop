﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BuyMe.Data.Migrations
{
    /// <inheritdoc />
    public partial class CustomerTableUpdates : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "GoogleId",
                table: "tblCustomer",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "IsGoogleLogin",
                table: "tblCustomer",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "GoogleId",
                table: "tblCustomer");

            migrationBuilder.DropColumn(
                name: "IsGoogleLogin",
                table: "tblCustomer");
        }
    }
}
