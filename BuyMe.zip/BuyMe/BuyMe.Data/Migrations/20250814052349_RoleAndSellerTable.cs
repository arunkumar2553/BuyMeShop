﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BuyMe.Data.Migrations
{
    /// <inheritdoc />
    public partial class RoleAndSellerTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tblRole",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RedirectTo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<int>(type: "int", nullable: false),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblRole", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "tblSeller",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Date_of_Birth = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Password = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Contact_No = table.Column<string>(type: "nvarchar(12)", maxLength: 12, nullable: false),
                    RoleId = table.Column<int>(type: "int", nullable: false),
                    Pincode = table.Column<int>(type: "int", maxLength: 6, nullable: false),
                    City = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    State = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Country = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Full_Address = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Identification_Type = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Identification_Number = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    LastLoginDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: false),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblSeller", x => x.Id);
                    table.ForeignKey(
                        name: "FK_tblSeller_tblRole_RoleId",
                        column: x => x.RoleId,
                        principalTable: "tblRole",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tblSeller_Bank_Details",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SellerId = table.Column<int>(type: "int", nullable: false),
                    Account_Holder_Name = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Account_Number = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    IFSC_Code = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Bank_Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Branch_Address = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CreatedBy = table.Column<int>(type: "int", nullable: false),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblSeller_Bank_Details", x => x.Id);
                    table.ForeignKey(
                        name: "FK_tblSeller_Bank_Details_tblSeller_SellerId",
                        column: x => x.SellerId,
                        principalTable: "tblSeller",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tblSeller_Business_Details",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SellerId = table.Column<int>(type: "int", nullable: false),
                    Business_Name = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Business_Description = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Contact_No = table.Column<string>(type: "nvarchar(12)", maxLength: 12, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    GSTIN = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Pincode = table.Column<int>(type: "int", maxLength: 6, nullable: false),
                    City = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    State = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Country = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    FullAddress = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    IsLicensed = table.Column<bool>(type: "bit", nullable: false),
                    IsLicenseExpiredOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: false),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedBy = table.Column<int>(type: "int", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblSeller_Business_Details", x => x.Id);
                    table.ForeignKey(
                        name: "FK_tblSeller_Business_Details_tblSeller_SellerId",
                        column: x => x.SellerId,
                        principalTable: "tblSeller",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_tblSeller_RoleId",
                table: "tblSeller",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_tblSeller_Bank_Details_SellerId",
                table: "tblSeller_Bank_Details",
                column: "SellerId");

            migrationBuilder.CreateIndex(
                name: "IX_tblSeller_Business_Details_SellerId",
                table: "tblSeller_Business_Details",
                column: "SellerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tblSeller_Bank_Details");

            migrationBuilder.DropTable(
                name: "tblSeller_Business_Details");

            migrationBuilder.DropTable(
                name: "tblSeller");

            migrationBuilder.DropTable(
                name: "tblRole");
        }
    }
}
