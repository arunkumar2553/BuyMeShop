﻿using BuyMe.Data.DbClasses;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuyMe.Data
{
    public class ApplicationDbContext: DbContext
    {
        public ApplicationDbContext()
        {

        }

        public DbSet<Seller> tblSeller { get; set; }
        public DbSet<Role> tblRole { get; set; }
        public DbSet<Seller_Business_Details> tblSeller_Business_Details { get; set; }
        public DbSet<Seller_Bank_Details> tblSeller_Bank_Details { get; set; }
        public DbSet<Customer> tblCustomer  { get; set; }
        public DbSet<CustomerAddress> tblCustomerAddress { get; set; }
        public DbSet<AddressType> tblAddressType { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=WSAMZN-VS0HIF83\\DEVSQLSERVER;Database=BuyMe; Trusted_Connection=True;TrustServerCertificate=True;Integrated Security=True;");

        }

    }
}
