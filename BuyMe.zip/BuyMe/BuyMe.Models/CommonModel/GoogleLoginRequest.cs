﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuyMe.Models.CommonModel
{
    public class GoogleLoginRequest
    {
  
        public string Token { get; set; }
    }
}
