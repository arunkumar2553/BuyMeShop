﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuyMe.Models.Model
{
    public class SellerModel
    {
        public SellerBasicDetailsModel sellerBasicDetailsModel { get; set; }
        public SellerBankDetailsModel sellerBankDetailsModel { get; set; }
        public SellerBusinessDetailsModel sellerBusinessDetailsModel { get; set; }
        public SellerModel()
        {
            sellerBasicDetailsModel = new SellerBasicDetailsModel();
            sellerBankDetailsModel = new SellerBankDetailsModel();
            sellerBusinessDetailsModel = new SellerBusinessDetailsModel();
        }
    }
    public class SellerBasicDetailsModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Gender { get; set; } = string.Empty;
        public string DateOfBirth { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Contact { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public int RoleId { get; set; }
        public string IdentificationType { get; set; } = string.Empty;
        public string IdentificationNumber { get; set; } = string.Empty;
        public int Pincode { get; set; }
        public string City { get; set; } = string.Empty;
        public string State { get; set; } = string.Empty;
        public string Country { get; set; } = string.Empty;
        public string FullAddress { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public bool IsActive { get; set; }
    }
    public class SellerBusinessDetailsModel
    {
        public int SellerId { get; set; }
        public string BusinessName { get; set; } = string.Empty;
        public string BusinessDescription { get; set; } = string.Empty;
        public string BusinessEmail  { get; set; } = string.Empty;
        public string BusinessContact { get; set; } = string.Empty;
        public string GSTIN { get; set; } = string.Empty;
        public int Pincode { get; set; }
        public string City { get; set; } = string.Empty;
        public string State { get; set; } = string.Empty;
        public string Country { get; set; } = string.Empty;
        public string FullAddress { get; set; } = string.Empty;
        public bool IsLicensed { get; set; }
        public DateTime? IsLicenseExpiredOn { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public bool IsActive { get; set; }

    }
    public class SellerBankDetailsModel
    {
        public int SellerId { get; set; }
        public string AccountHolderName { get; set; } = string.Empty;
        public string AccountNumber { get; set; } = string.Empty;
        public string IFSCCode { get; set; } = string.Empty;
        public string BankName { get; set; } = string.Empty;
        public string Branch { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public bool IsActive { get; set; }
    }
}
