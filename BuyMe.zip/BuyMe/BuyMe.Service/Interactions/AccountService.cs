﻿using BuyMe.Data;
using BuyMe.Data.DbClasses;
using BuyMe.Models.CommonModel;
using BuyMe.Models.Model;
using BuyMe.Models.UIModel;
using Google.Apis.Auth;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace BuyMe.Service.Interactions
{
    public class AccountService : IDisposable
    {
        #region Private Variables

        private ApplicationDbContext _dbContext;


        private Component component = new Component();
        private bool disposed = false;
        private IntPtr handle;

        private void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                    component.Dispose();
                CloseHandle(handle);
                handle = IntPtr.Zero;
            }
            disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        [System.Runtime.InteropServices.DllImport("Kernel32")]
        private extern static Boolean CloseHandle(IntPtr handle);

        #endregion

        #region Constructor

        public AccountService()
        {
            _dbContext = new ApplicationDbContext();
        }

        #endregion

        #region Destructor

        ~AccountService()
        {
            Dispose(false);
        }

        #endregion


        public async Task<ApiResponseModel> SellerRegistration(SellerModel sellerModel)
        {
            var apiResponseModel = new ApiResponseModel();

            var transaction = _dbContext.Database.BeginTransaction();
            var errorArea = string.Empty;

            try
            {
                var checkSellerDuplicacy = await _dbContext.tblSeller.Where(x => x.Contact_No == sellerModel.sellerBasicDetailsModel.Contact && x.Email == sellerModel.sellerBasicDetailsModel.Email && x.Id != sellerModel.sellerBasicDetailsModel.Id).FirstOrDefaultAsync();

                if (checkSellerDuplicacy != null)
                {
                    apiResponseModel.Status = false;
                    apiResponseModel.Message = "This mobile number and email is already registered, please try with new.";
                }

                else
                {
                    errorArea = "basic details";

                    var sellerObj = new Seller();

                    sellerObj.Name = sellerModel.sellerBasicDetailsModel.Name;
                    sellerObj.Email = sellerModel.sellerBasicDetailsModel.Email;
                    sellerObj.Contact_No = sellerModel.sellerBasicDetailsModel.Contact;
                    sellerObj.Password = sellerModel.sellerBasicDetailsModel.Password;
                    sellerObj.Date_of_Birth = sellerModel.sellerBasicDetailsModel.DateOfBirth;
                    sellerObj.Gender = sellerModel.sellerBasicDetailsModel.Gender;
                    sellerObj.RoleId = sellerModel.sellerBasicDetailsModel.RoleId;
                    sellerObj.Identification_Type = sellerModel.sellerBasicDetailsModel.IdentificationType;
                    sellerObj.Identification_Number = sellerModel.sellerBasicDetailsModel.IdentificationNumber;
                    sellerObj.Pincode = sellerModel.sellerBasicDetailsModel.Pincode;
                    sellerObj.City = sellerModel.sellerBasicDetailsModel.City;
                    sellerObj.State = sellerModel.sellerBasicDetailsModel.State;
                    sellerObj.Country = sellerModel.sellerBasicDetailsModel.Country;
                    sellerObj.Full_Address = sellerModel.sellerBasicDetailsModel.FullAddress;
                    sellerObj.CreatedBy = 1;
                    sellerObj.CreatedOn = DateTime.Now;

                    await _dbContext.tblSeller.AddAsync(sellerObj);
                    await _dbContext.SaveChangesAsync();

                    errorArea = "business details";

                    var seller_Business_DetailsObj = new Seller_Business_Details();

                    seller_Business_DetailsObj.SellerId = sellerObj.Id;
                    seller_Business_DetailsObj.Business_Name = sellerModel.sellerBusinessDetailsModel.BusinessName;
                    seller_Business_DetailsObj.Business_Description = sellerModel.sellerBusinessDetailsModel.BusinessDescription;
                    seller_Business_DetailsObj.Email = sellerModel.sellerBusinessDetailsModel.BusinessEmail;
                    seller_Business_DetailsObj.Contact_No = sellerModel.sellerBusinessDetailsModel.BusinessContact;
                    seller_Business_DetailsObj.GSTIN = sellerModel.sellerBusinessDetailsModel.GSTIN;
                    seller_Business_DetailsObj.Pincode = sellerModel.sellerBusinessDetailsModel.Pincode;
                    seller_Business_DetailsObj.City = sellerModel.sellerBusinessDetailsModel.City;
                    seller_Business_DetailsObj.State = sellerModel.sellerBusinessDetailsModel.State;
                    seller_Business_DetailsObj.Country = sellerModel.sellerBusinessDetailsModel.Country;
                    seller_Business_DetailsObj.FullAddress = sellerModel.sellerBusinessDetailsModel.FullAddress;
                    seller_Business_DetailsObj.CreatedBy = 1;
                    seller_Business_DetailsObj.CreatedOn = DateTime.Now;
                    seller_Business_DetailsObj.IsActive = true;

                    await _dbContext.tblSeller_Business_Details.AddAsync(seller_Business_DetailsObj);
                    await _dbContext.SaveChangesAsync();

                    errorArea = "bank details";

                    var seller_Bank_DetailsObj = new Seller_Bank_Details();

                    seller_Bank_DetailsObj.SellerId = sellerObj.Id;
                    seller_Bank_DetailsObj.Account_Holder_Name = sellerModel.sellerBankDetailsModel.AccountHolderName;
                    seller_Bank_DetailsObj.Account_Number = sellerModel.sellerBankDetailsModel.AccountNumber;
                    seller_Bank_DetailsObj.IFSC_Code = sellerModel.sellerBankDetailsModel.IFSCCode;
                    seller_Bank_DetailsObj.Bank_Name = sellerModel.sellerBankDetailsModel.BankName;
                    seller_Bank_DetailsObj.Branch_Address = sellerModel.sellerBankDetailsModel.Branch;
                    seller_Bank_DetailsObj.CreatedBy = 1;
                    seller_Bank_DetailsObj.CreatedOn = DateTime.Now;
                    seller_Bank_DetailsObj.IsActive = true;

                    await _dbContext.tblSeller_Bank_Details.AddAsync(seller_Bank_DetailsObj);
                    await _dbContext.SaveChangesAsync();
                }

                transaction.Commit();
                apiResponseModel.Status = true;
                apiResponseModel.Message = "Well Done! Your registration request has been successfully sent to admin. Please check Your Email for admin response.";
            }

            catch (Exception ex)
            {
                var msg = ex.Message;
                transaction.Rollback();
                apiResponseModel.Status = false;
                apiResponseModel.Message = "Sorry, an error occurred while saving the entries, please check your " + errorArea + ".";
            }

            return apiResponseModel;
        }

        public async Task<ApiResponseModel> UserLogin(string username, string password)
        {
            var apiResponseModel = new ApiResponseModel();

            dynamic? dbUser = null;

            try
            {
                var checkUserDetails = await _dbContext.tblSeller.Where(x => x.Contact_No == username || x.Email == username).FirstOrDefaultAsync();

                if (checkUserDetails != null)
                {
                    dbUser = checkUserDetails;
                }
                else
                {
                    //var checkCustomer = await _dbContext.tblCustomer.Where(x => x.Mobile == username || x.Email == username).FirstOrDefaultAsync();
                    //if (checkCustomer != null)
                    //{
                    //    dbUser = checkCustomer;
                    //}
                }

                if (dbUser != null)
                {
                    if (dbUser.Password != password)
                    {
                        apiResponseModel.Status = false;
                        apiResponseModel.Message = "Incorrect password.";
                    }
                    else if (!dbUser.IsActive)
                    {
                        apiResponseModel.Status = false;
                        apiResponseModel.Message = "User is not active.";
                    }
                    else
                    {
                        Int16 roleId = Convert.ToInt16(dbUser.RoleId);

                        var role = _dbContext.tblRole.Where(x => x.Id == roleId).FirstOrDefault();

                        var userDetails = new UsersDetailModel()
                        {
                            Id = dbUser.Id,
                            Name = dbUser.Name,
                            Email = dbUser.Email,
                            Contact_No = dbUser.Contact_No,
                            Redirect = role.RedirectTo,
                            Role = role.RoleName
                        };

                        dbUser.LastLoginDate = DateTime.Now;
                        await _dbContext.SaveChangesAsync();

                        apiResponseModel.Status = true;
                        apiResponseModel.Message = "User logged in successfully.";
                        apiResponseModel.Response = userDetails;
                    }
                }
                else
                {
                    apiResponseModel.Status = false;
                    apiResponseModel.Message = "User not found.";
                }
            }
            catch (Exception ex)
            {
                var message = ex.Message;
            }

            return apiResponseModel;
        }

        public async Task<ApiResponseModel> CustomerRegistration(CustomerModel customerModel)
        {
            var apiResponseModel = new ApiResponseModel();

            try
            {
                var isCustomerExists = await _dbContext.tblCustomer.Where(x => x.Mobile == customerModel.Mobile).FirstOrDefaultAsync();

                if (isCustomerExists != null)
                {
                    apiResponseModel.Status = false;
                    apiResponseModel.Message = "This mobile number is already registered.";
                }

                else
                {
                    var dbCustomer = new Customer();

                    dbCustomer.Name = customerModel.Name;
                    dbCustomer.Email = customerModel.Email;
                    dbCustomer.Mobile = customerModel.Mobile;
                    dbCustomer.Password = customerModel.Password;
                    dbCustomer.CreatedBy = customerModel.CreatedBy;
                    dbCustomer.CreatedOn = DateTime.Now;
                    dbCustomer.IsActive = true;

                    await _dbContext.tblCustomer.AddAsync(dbCustomer);
                    await _dbContext.SaveChangesAsync();

                    apiResponseModel.Status = true;
                    apiResponseModel.Message = "Customer registered successfully.";
                }
            }
            catch (Exception ex)
            {
                var message = ex.Message;
            }

            return apiResponseModel;
        }

       
    }
}
